import "./style.css";
const mans = () => {
    return (
        <div className="mans_pos">
            <img src="./mans/image-15@2x.png" alt="" className="man_style"/>
            <img src="./mans/image-16@2x.png" alt="" className="man_style"/>
            <img src="./mans/image-17@2x.png" alt="" className="man_style"/>
            <img src="./mans/image-18@2x.png" alt="" className="man_style"/>
            <img src="./mans/image-19@2x.png" alt="" className="man_style"/>
            <img src="./mans/image-20@2x.png" alt="" className="man_style"/>
            <img src="./mans/image-21@2x.png" alt="" className="man_style"/>
            <img src="./mans/image-22@2x.png" alt="" className="man_style"/>
            <img src="./mans/image-23@2x.png" alt="" className="man_style"/>
            <img src="./mans/image-24@2x.png" alt="" className="man_style"/>
            <img src="./mans/image-25@2x.png" alt="" className="man_style"/>
            <img src="./mans/image-26@2x.png" alt="" className="man_style"/>
        </div>
    )
}
export default mans;